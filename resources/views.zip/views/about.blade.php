@extends('layouts.home')

@section('content')

<!--=================================
breadcrumb -->
<div class="bg-light">
  <div class="container">
    <div class="row">
      <div class="col-12">
        <ol class="breadcrumb mb-0">
          <li class="breadcrumb-item">
            <a href="{{ url('/') }}"> <i class="fas fa-home"></i> </a>
          </li>
          <li class="breadcrumb-item">
            <i class="fas fa-chevron-right"></i> <span>About Us</span>
          </li>
        </ol>
      </div>
    </div>
  </div>
</div>
<!--=================================
breadcrumb -->

<!--=================================
About Direct Deal UAE -->
<section class="space-ptb bg-holder">
  <div class="container">

    <!-- HERO -->
    <div class="row justify-content-center mb-5">
      <div class="col-lg-10">
        <div class="text-center">
          <h1 class="text-primary mb-4">
            About Direct Deal UAE
          </h1>

          <p class="lead fw-normal mb-3">
            Direct Deal UAE is Dubai’s first
            <strong>zero-commission, fully verified real estate platform</strong>
            designed to eliminate brokers, fake listings, and inflated fees from property transactions.
          </p>

          <p class="px-sm-5">
            We enable property owners, buyers, landlords, and tenants to connect directly through a secure,
            verified, and transparent process — saving time, money, and frustration.
          </p>
        </div>
      </div>
    </div>

    <!-- VERIFIED PLATFORM -->
    <div class="row justify-content-center">
      <div class="col-lg-10">
        <p>
          Unlike traditional real estate portals and agencies, every listing on
          <strong>DirectDealUAE.com</strong> is <strong>100% verified</strong> before it goes live.
          Ownership documents, identities, property details, and photos are checked to ensure only
          real properties and genuine users are allowed on the platform.
        </p>
      </div>
    </div>

    <!-- MISSION -->
    <div class="row justify-content-center mt-5">
      <div class="col-lg-8">
        <div class="p-4 bg-light rounded shadow-sm text-center">
          <h3 class="text-primary mb-3">Our Mission</h3>
          <p class="mb-0 fw-normal">
            To create a fair, commission-free way to buy, sell, and rent property in Dubai using technology,
            verification, and transparency — without agents or hidden charges.
          </p>
        </div>
      </div>
    </div>

    <!-- DIFFERENT -->
    <div class="row mt-5">
      <div class="col-12 text-center mb-4">
        <h2>What Makes Direct Deal UAE Different</h2>
      </div>

      <div class="col-lg-4 col-sm-6 mb-4">
        <div class="feature-info h-100">
          <div class="feature-info-icon">
            <i class="flaticon-like"></i>
          </div>
          <div class="feature-info-content">
            <h6 class="feature-info-title">Zero Commission for Sellers & Landlords</h6>
            <p>List properties for sale or rent completely free.</p>
          </div>
        </div>
      </div>

      <div class="col-lg-4 col-sm-6 mb-4">
        <div class="feature-info h-100">
          <div class="feature-info-icon">
            <i class="flaticon-agent"></i>
          </div>
          <div class="feature-info-content">
            <h6 class="feature-info-title">Lowest Fees in the Market</h6>
            <p>
              Buyers pay only <strong>0.2%</strong>, tenants pay only
              <strong>0.5%</strong> of annual rent — instead of 2%–5%.
            </p>
          </div>
        </div>
      </div>

      <div class="col-lg-4 col-sm-6 mb-4">
        <div class="feature-info h-100">
          <div class="feature-info-icon">
            <i class="flaticon-like-1"></i>
          </div>
          <div class="feature-info-content">
            <h6 class="feature-info-title">100% Verified Listings & Users</h6>
            <p>No fake ads, duplicate listings, or unqualified leads.</p>
          </div>
        </div>
      </div>

      <div class="col-lg-4 col-sm-6 mb-4">
        <div class="feature-info h-100">
          <div class="feature-info-icon">
            <i class="flaticon-house-1"></i>
          </div>
          <div class="feature-info-content">
            <h6 class="feature-info-title">Direct Connections, No Agents</h6>
            <p>We remove middlemen while acting as a neutral, secure facilitator.</p>
          </div>
        </div>
      </div>

      <div class="col-lg-4 col-sm-6 mb-4">
        <div class="feature-info h-100">
          <div class="feature-info-icon">
            <i class="flaticon-house-key-1"></i>
          </div>
          <div class="feature-info-content">
            <h6 class="feature-info-title">End-to-End Support</h6>
            <p>From verification and contracts to Ejari and transfer coordination.</p>
          </div>
        </div>
      </div>

      <div class="col-lg-4 col-sm-6 mb-4">
        <div class="feature-info h-100">
            <div class="feature-info-icon">
                <i class="flaticon-like"></i>
            </div>
            <div class="feature-info-content">
                <h6 class="feature-info-title">
                    100% Verified Properties in Dubai
                </h6>
                <p class="mb-0">
                    Every property on Direct Deal UAE is manually verified for ownership,
                    accuracy, and authenticity before going live — ensuring only genuine
                    Dubai properties reach buyers and tenants.
                </p>
            </div>
        </div>
      </div>

    </div>

    <!-- TRUST -->
    <div class="row justify-content-center mt-5">
      <div class="col-lg-10 text-center">
        <h3 class="text-primary mb-3">Built for Trust in Dubai Real Estate</h3>
        <p>
          Dubai’s real estate market suffers from fake listings and unnecessary commissions.
          Direct Deal UAE solves this problem by allowing only verified owners, buyers, landlords,
          and tenants to interact — ensuring smoother, safer transactions.
        </p>
      </div>
    </div>

    <!-- WHO WE SERVE -->
    <div class="row justify-content-center mt-4">
      <div class="col-lg-8">
        <ul class="list-unstyled text-center">
          <li>✔ Property owners selling or renting directly</li>
          <li>✔ Buyers looking for genuine properties</li>
          <li>✔ Tenants who don’t want to pay 5% commission</li>
          <li>✔ Investors seeking verified opportunities</li>
          <li>✔ Developers promoting new off-plan projects</li>
        </ul>
      </div>
    </div>

    <!-- BRAND CLOSE -->
    <div class="row justify-content-center mt-5">
      <div class="col-lg-10 text-center">
        <p class="fw-semibold">
          Direct Deal UAE is not an agency.
          It is a proptech platform built to make Dubai real estate simple, direct, and honest.
        </p>
        <h5 class="text-primary mt-2">
          Be Direct. Be Intelligent. Just Direct Deals.
        </h5>
      </div>
    </div>

  </div>
</section>
<!--=================================
About Direct Deal UAE -->

@endsection
