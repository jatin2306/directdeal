@extends('layouts.home')

@section('content')
<style>
.banner {
    padding: 150px 0;
    position: relative;
}
.property-search-field {
    border-radius: 12px;
    box-shadow: 0 4px 20px rgba(0, 0, 0, 0.07);
    padding: 20px;
    margin-top: 20px;
}

.property-search-field .form-group {
    margin-bottom: 0px;
}
.property-search-field .form-group:first-child {
   border-bottom-left-radius:12px;
}

.property-search-field .form-label {
    font-weight: 600;
    color: #26ae61; /* Your theme color */
}

.property-search-field .form-control {
    border-radius: 8px;
    border: 1px solid #e2e2e2;
    transition: 0.3s ease;
}

.property-search-field .btn-primary {
    background-color: #26ae61;
    border-color: #26ae61;
    border-radius: 8px;
    padding: 8px 20px;
    transition: 0.3s ease;
}

.property-search-field .btn-primary:hover {
    background-color: #02853a;
    border-color: #02853a;
}

.property-search-field .fa-search {
    font-size: 16px;
    margin-right: 5px;
}

.more-search {
    color: #26ae61;
    font-weight: 500;
    transition: color 0.3s;
}

.more-search:hover {
    color: #36194d;
    text-decoration: none;
}

.advanced-search .card {
    border-radius: 12px;
    box-shadow: 0 4px 15px rgba(0, 0, 0, 0.06);
}

.property-search-field .property-search-item {
    
    border-radius: 12px;
}

/* Enhanced Feature Section Styles */
.bg-light.p-4.py-5.text-center {
    background: #e9f7f0 !important;
    border-radius: 16px;
    box-shadow: 0 3px 3px #e9f7f0;
    transition: all 0.3s ease;
}

.bg-light.p-4.py-5.text-center:hover {
    box-shadow: 0 8px 15px rgba(0, 0, 0, 0.12);
    transform: translateY(-4px);
}

.bg-light.p-4.py-5.text-center i {
    font-size: 40px;
    color: #4a225b; /* Theme color */
    margin-bottom: 20px;
    transition: color 0.3s;
}

.bg-light.p-4.py-5.text-center h5 {
    font-weight: 600;
    color: #333;
}

.bg-light.p-4.py-5.text-center p {
    font-size: 14px;
    color: #555;
    line-height: 1.6;
}

/* Feature Property section CSS */

.property-link {
    border: none;
  padding: 12px 0;
  font-weight: 600;
  border-radius: 0 0 3px 3px;
  background-color: #e9f7f0; /* Theme primary */
  color: #26ad60;
  transition: all 0.3s ease;
  display: block;
  text-decoration: none;
}

/* Location Properties */
.location-item {
  position: relative;
  height: 100%;
  min-height: 240px;
  background-size: cover;
  background-position: center;
  border-radius: 12px;
  overflow: hidden;
  display: flex;
  align-items: flex-end;
  transition: all 0.4s ease;
  box-shadow: 0 6px 18px rgba(0, 0, 0, 0.08);
}

.location-item-big {
  min-height: 500px;
}

.location-item:hover {
  transform: translateY(-6px);
  box-shadow: 0 12px 24px rgba(0, 0, 0, 0.15);
}

.location-item-info {
  width: calc(100% - 40px);
  padding: 20px 25px;
  background: linear-gradient(to top, rgba(0,0,0,0.6), rgba(0,0,0,0));
  color: #fff;
  border-radius: 0 0 12px 12px;
}

.location-item-title {
  font-size: 1.25rem;
  font-weight: 600;
  margin-bottom: 5px;
}

.location-item-list {
  font-size: 0.95rem;
  opacity: 0.9;
}

@media (max-width: 767px) {
  .location-item-big {
    min-height: 300px;
  }

  .location-item {
    min-height: 200px;
  }

  .location-item-info {
    padding: 16px;
  }

  .location-item-title {
    font-size: 1.1rem;
  }

  .location-item-list {
    font-size: 0.875rem;
  }
}

.btn-outline-secondary:not(:disabled):not(.disabled):active,.btn-outline-secondary:focus {
    background: #fff !important;
    color: #ffffff;
    border-color: #fff !important;
}


</style>
    <!--=================================
        banner -->
    <section class="position-relative">

        <div class="relative">
        <div class="slider">
        <div class="slides" style="transform: translateX(0%);">

        <div class="slidee overlay" style=" background-image: linear-gradient(rgba(0,0,0,0.6), rgba(0,0,0,0.6)), url('https://directdealuae.com/images/Direct_Deal_Banner01.jpg'); "> 
        <div class="content"> 
        <p>Buy or sell</p> 
        <h3>Be Direct! Be Intelligent!</h3> 
         <a href="{{ route('submit.property') }}" class="btn">GET STARTED</a> 
        </div> 
        </div>


        <!--<div class="slidee" style="background-image: url(https://i.ibb.co/KpHXXVKH/srk.png);"> -->
        <!--<div class="content"> -->
        <!--<p>Buy or sell</p> -->
        <!--<h3>Direct Deal provides an excellent solution!</h3> -->
        <!--<a href="https://directdealuae.com/properties" class="btn">GET STARTED</a>-->
        <!--</div> -->
        <!--</div>-->


        </div>

        <!-- Controls -->
        
        <!--<div class="prev"></div>-->
        <!--<div class="next"></div>-->

        <!-- Dots -->
        
        </div>

        <!--<div class="dots">-->
        <!--    <div class="dot active"></div>-->
        <!--    <div class="dot"></div>-->
        <!--</div>-->

        </div>
        
    </section>
    

    <style>

.slider {
      position: relative;
      width: 100%;
      height: 30dvh;
      overflow: hidden;
      min-height:300px;
    }

    .slides {
      display: flex;
      transition: transform 0.6s ease-in-out;
      height: 100%;
    }

    .slidee {
      min-width: 100%;
      height: 100%;
      background-size: cover;
      background-position: 70% center;
      position: relative;
      display: flex;
      align-items: center;
    /* border-radius: 20px; */
      /* padding: 40px; */
    }
.slidee .img {
    padding: 30px 80px 0 0;
}
    /* Navigation arrows */

    .prev, .next {
    position: absolute;
    top: 50%;
    border-radius: 50%;
    padding: 12px;
    cursor: pointer;
    font-size: 20px;
    color: #000;
    user-select: none;
    height: 30px;
    width: 30px;
}

.prev {
    left: 15px;
    background: url(https://images.pixazo.ai/sitefiles/arrowVector.svg);
    background-size: cover;
    transform: rotate(180deg);
}
.next {
    right: 15px;
    background: url(https://images.pixazo.ai/sitefiles/arrowVector.svg);
    background-size: cover;
}


    /* Dots */
    .dots {
      position: absolute;
      bottom: -25px;
      left: 50%;
      transform: translateX(-50%);
      display: flex;
      gap: 8px;
    }

    .dot {
      width: 12px;
      height: 12px;
      border-radius: 50%;
      background: #777;
      cursor: pointer;
    }

    .dot.active {
      background: #28a745;
    }
    .relative{
        position: relative;
    }

    .slider {
      position: relative;
      width: 100%;
      height: 30dvh;
      overflow: hidden;
      min-height:300px;
    }

    .slides {
      display: flex;
      transition: transform 0.6s ease-in-out;
      height: 100%;
    }

    .content {
      padding: 20px;
      margin-left: 100px;
      color: #fff;
      /* max-width: 500px; */
    }

    .content h3 {
      font-size: 35px;
      font-weight: 700;
      margin-bottom: 15px;
      color: #fff;
    }

    .content p {
        font-size: 16px;
        margin-bottom: 0;
        color: #26AE61;
    }

    .content .btn {
        display: inline-block;
        background: #26AE61;
        color: #fff;
        padding: 12px 20px;
        border-radius: 6px;
        font-weight: 400;
        text-decoration: none;
        font-size: 14px;
    }
.content .freecard{display: block; font-size: 11px; line-height: 2;font-weight: bold;}

    /* Navigation arrows */

.prev, .next {
    position: absolute;
    top: 50%;
    border-radius: 50%;
    padding: 12px;
    cursor: pointer;
    font-size: 20px;
    color: #000;
    user-select: none;
    height: 30px;
    width: 30px;
}

.prev {
    left: 15px;
    background: url(https://images.pixazo.ai/sitefiles/arrowVector.svg);
    background-size: cover;
    transform: rotate(180deg);
}
.next {
    right: 15px;
    background: url(https://images.pixazo.ai/sitefiles/arrowVector.svg);
    background-size: cover;
}


    /* Dots */
    .dots {
      position: absolute;
      bottom: -25px;
      left: 50%;
      transform: translateX(-50%);
      display: flex;
      gap: 8px;
    }

    .dot {
      width: 12px;
      height: 12px;
      border-radius: 50%;
      background: #777;
      cursor: pointer;
    }


    .relative{
        position: relative;
    }

    /* Responsive */
    @media (max-width: 768px) {

.clientMob{display: block;}

      .slider { min-height: 220px; }
      .content h3 { font-size: 18px; }
      .content p { font-size: 12px; line-height: 16px; }
      .content .btn { padding: 8px 12px; font-size: 12px; }
      h1 { font-size: 25px; }
      h2 { font-size: 15px; }
      .content { margin-left: 0; }
      .prev, .next { display: none; }
      .content { max-width: 250px; z-index: 1;}
      .slidee { height: 200px; position: relative; }
.slidee .img{  padding: 20px 00px 0 0;}
.slidee:before {
    content: "";
    background: #00000045;
    height: 100%;
    width: 100%;
    position: absolute;
}
 .model-img img {
        max-height: auto !important;
        height: auto !important;
    }
    }


</style>

<script>

const sliderTrack1 = document.querySelector('.slides');
const slideItems1 = document.querySelectorAll('.slidee');
const buttonPrev1 = document.querySelector('.prev');
const buttonNext1 = document.querySelector('.next');
const navigationDots1 = document.querySelectorAll('.dot');

let currentIndex1 = 0;
let dragStartX1 = 0;
let dragEndX1 = 0;

function showSlideAt1(indexToShow1) {
  if (indexToShow1 < 0) {
    currentIndex1 = slideItems1.length - 1;
  } else if (indexToShow1 >= slideItems1.length) {
    currentIndex1 = 0;
  } else {
    currentIndex1 = indexToShow1;
  }

  sliderTrack1.style.transform = `translateX(-${currentIndex1 * 100}%)`;
  navigationDots1.forEach((dot1, i1) => {
    dot1.classList.toggle('active', i1 === currentIndex1);
  });
}

buttonPrev1.addEventListener('click', () => showSlideAt1(currentIndex1 - 1));
buttonNext1.addEventListener('click', () => showSlideAt1(currentIndex1 + 1));
navigationDots1.forEach((dot1, i1) => {
  dot1.addEventListener('click', () => showSlideAt1(i1));
});

// --- Drag / Swipe Support ---
sliderTrack1.addEventListener('touchstart', (event1) => {
  dragStartX1 = event1.touches[0].clientX;
});

sliderTrack1.addEventListener('touchend', (event1) => {
  dragEndX1 = event1.changedTouches[0].clientX;
  detectSwipeDirection1();
});

sliderTrack1.addEventListener('mousedown', (event1) => {
  dragStartX1 = event1.clientX;
});

sliderTrack1.addEventListener('mouseup', (event1) => {
  dragEndX1 = event1.clientX;
  detectSwipeDirection1();
});

function detectSwipeDirection1() {
  const swipeDistance1 = dragEndX1 - dragStartX1;
  const swipeThreshold1 = 50; // Minimum px to count as swipe
  if (Math.abs(swipeDistance1) > swipeThreshold1) {
    if (swipeDistance1 > 0) {
      showSlideAt1(currentIndex1 - 1); // swipe right
    } else {
      showSlideAt1(currentIndex1 + 1); // swipe left
    }
  }
}

</script>

    <!--=================================
          banner -->

    <!--=================================
        property Type -->


    <section class="property-search-field-top position-reletive">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="property-search-field bg-white">
                        <div class="property-search-item">
                            <form method="GET" action="{{ route('property.index') }}" class="row basic-select-wrapper align-items-end">

                                <!-- Location Filter -->
                                <div class="form-group col-lg-3 col-md-6 position-relative home">
                                    <label class="form-label fw-semibold">{{ translate('Location') }}</label>

                                    <div class="location-input-wrapper">
                                        <i class="fas fa-search location-search-icon"></i>

                                        <input
                                            type="text"
                                            name="location"
                                            id="location-input"
                                            class="form-control location-input"
                                            placeholder="City, community or building"
                                            autocomplete="off"
                                            value="{{ request('location') }}"
                                        >
                                    </div>

                                    <div id="location-dropdown" class="location-dropdown d-none">
                                        <div class="location-title">Popular locations</div>

                                        @foreach ($locations as $location)
                                            <div class="location-option" data-value="{{ $location }}">
                                                <i class="fas fa-map-marker-alt"></i>
                                                <span>{{ $location }}</span>
                                            </div>
                                        @endforeach
                                    </div>
                                </div>

                                <!-- Property Type Filter -->
                                <div class="form-group col-lg-3 col-md-6">
                                    <label class="form-label fw-semibold">{{ translate('Property Type') }}</label>
                                    <select name="propertyType" id="propertyType" class="form-control basic-select">
                                        <option value="">{{ translate('All In Residential') }}</option>
                                        @foreach ($propertyTypes as $key => $type)
                                            <option value="{{ $key }}" {{ request('propertyType') == $key ? 'selected' : '' }}>
                                                {{ translate($type) }}
                                            </option>
                                        @endforeach
                                    </select>
                                </div>

                                <!-- Budget Filter -->
                                <div class="form-group col-lg-2 col-md-6">
                                    <label class="form-label fw-semibold">{{ translate('Budget') }}</label>
                                    <select name="budget" id="budget" class="form-control basic-select">
                                        <option value="">{{ translate('Any') }}</option>
                                        <option value="0-50000" {{ request('budget') == '0-50000' ? 'selected' : '' }}>Under 50K</option>
                                        <option value="50000-100000" {{ request('budget') == '50000-100000' ? 'selected' : '' }}>50K - 100K</option>
                                        <option value="100000-200000" {{ request('budget') == '100000-200000' ? 'selected' : '' }}>100K - 200K</option>
                                        <option value="200000-500000" {{ request('budget') == '200000-500000' ? 'selected' : '' }}>200K - 500K</option>
                                        <option value="500000+" {{ request('budget') == '500000+' ? 'selected' : '' }}>500K+</option>
                                    </select>
                                </div>

                                <!-- Beds Filter -->
                                <div class="form-group col-lg-2 col-md-6">
                                    <label class="form-label fw-semibold">{{ translate('Beds') }}</label>
                                    <select name="bedrooms" id="bedrooms" class="form-control basic-select">
                                        <option value="">{{ translate('Any') }}</option>
                                        @for ($i = 1; $i <= 10; $i++)
                                            <option value="{{ $i }}" {{ request('bedrooms') == $i ? 'selected' : '' }}>
                                                {{ $i == 1 ? 'Studio' : $i . ' ' . translate('Beds') }}
                                            </option>
                                        @endfor
                                    </select>
                                </div>

                                <!-- Advance Dropdown -->
                                <!-- <div class="form-group col-lg-2 col-md-6">
                                    <label class="form-label fw-semibold">{{ translate('Advance') }}</label>
                                    <select class="form-control basic-select" data-bs-toggle="collapse" data-bs-target="#advanced-search">
                                        <option value="">{{ translate('More Filters') }}</option>
                                    </select>
                                </div> -->

                                <div class="form-group col-lg-2 col-md-6 position-relative d-none">
                                <label class="form-label fw-semibold">{{ translate('Advance') }}</label>

                                    <!-- Trigger -->
                                    <button class="form-control text-start advance-toggle" type="button">
                                        {{ translate('More Filters') }}
                                    </button>

                                    <!-- Dropdown Panel -->
                                    <div class="advance-dropdown-menu p-3 shadow">

                                        <!-- AREA -->
                                        <div class="mb-3">
                                            <label class="dropdown-label">{{ translate('Area (sqft)') }}</label>
                                            <input type="number" name="area" class="form-control"
                                                value="{{ request('area') }}" min="0" placeholder="{{ translate('Enter Area') }}">
                                        </div>

                                        <!-- BATHROOMS -->
                                        <div class="mb-3">
                                            <label class="dropdown-label">{{ translate('Bathrooms') }}</label>
                                            <select name="bathrooms" class="form-control basic-select">
                                                <option value="">{{ translate('Select Bathrooms') }}</option>
                                                @for ($i = 1; $i <= 10; $i++)
                                                    <option value="{{ $i }}" {{ request('bathrooms') == $i ? 'selected' : '' }}>
                                                        {{ $i }} {{ translate($i > 1 ? 'Bathrooms' : 'Bathroom') }}
                                                    </option>
                                                @endfor
                                            </select>
                                        </div>

                                        <!-- STATUS -->
                                        <div class="mb-3">
                                            <label class="dropdown-label">{{ translate('Status') }}</label>
                                            <select name="status" class="form-control basic-select">
                                                <option value="">{{ translate('Select Status') }}</option>
                                                @foreach ($statuses as $key => $status)
                                                    <option value="{{ $key }}" {{ request('status') == $key ? 'selected' : '' }}>
                                                        {{ $status }}
                                                    </option>
                                                @endforeach
                                            </select>
                                        </div>

                                        <button class="btn btn-primary w-100" type="submit">{{ translate('Apply Filters') }}</button>

                                    </div>
                                </div>




                                <!-- Search Button -->
                                <div class="form-group col-lg-2 col-md-6">
                                    <span class="align-items-center ms-3 d-none d-md-block my-auto">
                                        <button class="btn btn-primary d-flex align-items-center" type="submit">
                                            <i class="fas fa-search me-1"></i><span>{{ translate('Search') }}</span>
                                        </button>
                                    </span>
                                </div>

                                <!-- Advanced Search Section -->
                                <div class="collapse advanced-search p-0 mt-3" id="advanced-search">
                                    <div class="card card-body">
                                        <div class="row">
                                            <!-- Property Category Filter -->
                                            <div class="form-group col-md-4">
                                                <label class="form-label">{{ translate('Property Category') }}</label>
                                                <select name="property_category_id" id="category" class="form-control basic-select">
                                                    <option value="">{{ translate('Select Category') }}</option>
                                                    @foreach ($categories as $category)
                                                        <option value="{{ $category->id }}"
                                                            {{ request('property_category_id') == $category->id ? 'selected' : '' }}>
                                                            {{ translate($category->name) }}
                                                        </option>
                                                    @endforeach
                                                </select>
                                            </div>

                                            <!-- Bathrooms Filter -->
                                            <div class="form-group col-md-4">
                                                <label class="form-label">{{ translate('Bathrooms') }}</label>
                                                <select name="bathrooms" id="bathrooms" class="form-control basic-select">
                                                    <option value="">{{ translate('Select Bathrooms') }}</option>
                                                    @for ($i = 1; $i <= 10; $i++)
                                                        <option value="{{ $i }}"
                                                            {{ request('bathrooms') == $i ? 'selected' : '' }}>
                                                            {{ $i }} {{ translate($i > 1 ? 'Bathrooms' : 'Bathroom') }}
                                                        </option>
                                                    @endfor
                                                </select>
                                            </div>

                                            <!-- Specific Type Filter -->
                                            <div class="form-group col-md-4">
                                                <label class="form-label">{{ translate('Specific Type') }}</label>
                                                <select name="child_type_id" id="childType" class="form-control basic-select">
                                                    <option value="">{{ translate('Select Specific Type') }}</option>
                                                    @foreach ($childTypes as $childType)
                                                        <option value="{{ $childType->id }}"
                                                            {{ request('child_type_id') == $childType->id ? 'selected' : '' }}>
                                                            {{ translate($childType->name) }}
                                                        </option>
                                                    @endforeach
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <!-- Mobile Search Button -->
                                <!-- <div class="d-md-none d-grid btn-mobile my-3">
                                    <button class="btn btn-success d-grid align-items-center" type="submit">
                                        <i class="fas fa-search me-1"></i><span>{{ translate('Search') }}</span>
                                    </button>
                                </div> -->
                                <div class="d-md-none d-grid btn-mobile my-3">
                                    <button class="btn btn-primary align-items-center" type="submit">
                                        <i class="fas fa-search me-1"></i><span>{{ translate('Search') }}</span>
                                    </button>
                                </div>

                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>


    <section class="py-4 mt-4" style="background:#e9f7f0;">
        <div class="container text-center">
            <h1 class="fw-bold" style="color:#26AE61;">Buy, Sell & Rent Verified Properties in Dubai – Zero Commission</h1>
            <p class="mt-3 mb-4" style="color:#4A225B; font-size:18px;">
                Be Direct, Be Intelligent – The UAE’s first zero-commission, fully verified real estate platform.
                No agents. No fake listings. No inflated commissions. Just Direct Deals.
            </p>
            <a href="{{ url('properties') }}" class="btn btn-primary me-2 focus-none">Search Verified Properties</a>
            <a href="{{ route('submit.property') }}" class="btn btn-white border border-success mt-4 mt-md-0" style="color:#26AE61;">List Your Property Free</a>
        </div>
    </section>

    <!--=================================
        Property Types -->

    <!--=================================
        feature -->

        <section class="py-5 bg-white">
            <div class="container">

                <h2 class="text-center mb-4" style="color:#26AE61;">100% Verified Listings – No Fake Ads, No Time Wasters</h2>
                <p class="text-center mb-5" style="color:#4A225B;">
                    Every property on Direct Deal UAE goes through strict verification:
                </p>

                <div class="row text-center">

                    <div class="col-md-3 mb-4">
                        <div class="p-4 shadow-sm rounded bg-light h-100">
                            <h6 class="fw-bold text-dark">Ownership Documents Checked</h6>
                            <p class="small text-muted">We ensure the property is legally owned by the advertiser.</p>
                        </div>
                    </div>

                    <div class="col-md-3 mb-4">
                        <div class="p-4 shadow-sm rounded bg-light h-100">
                            <h6 class="fw-bold text-dark">Landlord Identity Verified</h6>
                            <p class="small text-muted">No fake agents. Only real owners and real landlords.</p>
                        </div>
                    </div>

                    <div class="col-md-3 mb-4">
                        <div class="p-4 shadow-sm rounded bg-light h-100">
                            <h6 class="fw-bold text-dark">Property Details Validated</h6>
                            <p class="small text-muted">Photos, size, location, and specs are inspected for accuracy.</p>
                        </div>
                    </div>

                    <div class="col-md-3 mb-4">
                        <div class="p-4 shadow-sm rounded bg-light h-100">
                            <h6 class="fw-bold text-dark">In-Person Review When Needed</h6>
                            <p class="small text-muted">We perform site visits when necessary to ensure authenticity.</p>
                        </div>
                    </div>

                </div>

                <p class="text-center mt-4" style="color:#26AE61; font-weight:600;">
                    No duplicates. No misleading ads. Only real, verified Dubai properties.
                </p>

            </div>
        </section>


    <section class="space-ptb d-none">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    
                    <div class="text-center">
                      <h2 class="mb-4">From Search to Sold – We’ve Got You Covered</h2>
                      <p class="px-sm-5 mb-4 lead fw-normal">Whether you're buying, selling, or renting, we guide you every step of the way with expert support, verified listings, and personalized service to make your property journey smooth and successful.</p>
                    </div>
                    
                </div>
                <div class="col-lg-3 col-sm-6 mb-4 mb-lg-0">
                    <div class="bg-light p-4 py-5 text-center h-100">
                        <i class="flaticon-agent font-xlll text-primary mb-4"></i>
                        <h5 class="mb-3">{{ translate('A shopper reaches out') }}</h5>
                        <p class="mb-0">{{ translate('The price is something not necessarily defined as financial. It could be time.') }}</p>
                    </div>
                </div>
                <div class="col-lg-3 col-sm-6 mb-4 mb-lg-0">
                    <div class="bg-light p-4 py-5 text-center h-100">
                        <i class="flaticon-like font-xlll text-primary mb-4"></i>
                        <h5 class="mb-3">{{ translate('We verify the lead') }}</h5>
                        <p class="mb-0">This is perhaps the single biggest obstacle that all of us must overcome.</p>
                    </div>
                </div>
                <div class="col-lg-3 col-sm-6 mb-4 mb-sm-0">
                    <div class="bg-light p-4 py-5 text-center h-100">
                        <i class="flaticon-room-key-1 font-xlll text-primary mb-4"></i>
                        <h5 class="mb-3">{{ translate('You connect live') }}</h5>
                        <p class="mb-0">{{ translate('One of the main areas that I work on with my clients is shedding these.') }}</p>
                    </div>
                </div>
                <div class="col-lg-3 col-sm-6">
                    <div class="bg-light p-4 py-5 text-center h-100">
                        <i class="flaticon-house-key-1 font-xlll text-primary mb-4"></i>
                        <h5 class="mb-3">{{ translate('Convert more deals') }}</h5>
                        <p class="mb-0">{{ translate('It is truly amazing the damage that we, as parents, can inflict on our children.') }}
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--=================================
        feature -->

    <!--=================================
Featured Properties-->
<section class="space-pb d-none">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="section-title mb-4">
                    <h2 class="mb-0">Featured Properties</h2>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-12">
                <div class="owl-carousel owl-nav-top-left" data-nav-arrow="true" data-items="3" data-md-items="3"
                    data-sm-items="2" data-xs-items="1" data-xx-items="1" data-space="20">
                    @foreach ($featuredProperties as $property)
                        <div class="item">
                            <div class="property-item rounded-3 shadow-sm border border-light-subtle overflow-hidden">
                                <div class="property-image bg-overlay-gradient-04 position-relative">
                                    <img class="img-fluid rounded-top"
                                        style="height: 220px; width: 100%; object-fit: cover; object-position: center;"
                                        src="{{ $property->pictures->first() ? Storage::url($property->pictures->first()->path) : asset('images/placeholder.jpg') }}"
                                        alt="">
                                    
                                    <!-- Trending icon - now top-left -->
                                    <span class="property-trending position-absolute top-0 start-0 text-warning">
                                        <i class="fas fa-bolt"></i>
                                    </span>

                                    <!-- Badges - now top-right -->
                                    <div class="property-lable position-absolute top-0 end-0 m-2 text-end">
                                        <span class="badge bg-primary me-1">{{ $property->childTypeRelation->name ?? 'No Type' }}</span>
                                        <span class="badge bg-info">{{ $propertyTypes[$property->propertyType] ?? 'Unknown' }}</span>
                                    </div>

                                    <div class="property-agent-popup position-absolute bottom-0 end-0 m-2 bg-white text-dark px-2 py-1 rounded">
                                        <i class="fas fa-camera me-1"></i>{{ $property->pictures->count() }}
                                    </div>
                                </div>
                                <div class="property-details p-3 bg-white">
                                    <h6 class="property-title mb-1 fw-semibold">
                                        <a href="{{ route('property.show', $property->id) }}" class="text-dark">
                                            {{ $property->propertyName }}
                                        </a>
                                    </h6>
                                    <p class="property-address text-muted small mb-2">
                                        <i class="fas fa-map-marker-alt me-1 text-primary"></i> {{ $property->address }}
                                    </p>
                                    <div class="d-flex justify-content-between align-items-center small mb-2 text-muted">
                                        <span><i class="far fa-clock me-1"></i>{{ $property->created_at->diffForHumans() }}</span>
                                        <span class="fw-bold text-dark">{{ number_format($property->price) }} AED 
                                            @if ($property->propertyType == 2)
                                                <small class="text-muted">/month</small>
                                            @endif
                                        </span>
                                    </div>
                                    <ul class="property-info list-unstyled d-flex justify-content-between text-center border-top pt-2 mt-2 mb-0 small">
                                        <li><i class="fas fa-bed text-primary me-1"></i>
                                            {{ $property->bedrooms == 0 ? 'Studio' : $property->bedrooms . ' Beds' }}
                                        </li>

                                        <li><i class="fas fa-bath text-primary me-1"></i>{{ $property->bathrooms }} Bath</li>
                                        <li><i class="far fa-square text-primary me-1"></i>{{ $property->builtArea }} m²</li>
                                    </ul>

                                </div>
                                <!-- Your original "See Details" part -->
                                <div class="property-btn">
                                  <a class="property-link btn btn-primary d-block text-center w-100" href="{{ route('property.show', $property->id) }}">See Details</a>
                                </div>
                            </div>
                        </div>
                    @endforeach
                </div>
            </div>
            <div class="col-12 text-center mt-4">
                <a class="btn btn-link fw-semibold text-primary" href="{{ url('properties') }}">
                    <i class="fas fa-plus me-1"></i>View All Listings
                </a>
            </div>
        </div>
    </div>
</section>
<!--=================================
Featured Properties-->



<!--- ===========================
Why Direct Deal -->


<section class="py-5 mb-5" style="background:#f7fdfb;">
    <div class="container">

        <h2 class="text-center mb-4" style="color:#26AE61;">Why Direct Deal UAE?</h2>

        <div class="row">

            <div class="col-md-4 mb-4">
                <div class="p-4 shadow-sm bg-white rounded h-100">
                    <h5 class="fw-bold text-dark">Zero Commission for Owners</h5>
                    <p>No 2% sales or 5% rental commission. Listing your property is completely free.</p>
                </div>
            </div>

            <div class="col-md-4 mb-4">
                <div class="p-4 shadow-sm bg-white rounded h-100">
                    <h5 class="fw-bold text-dark">Lowest Service Fees in the UAE</h5>
                    <p>
                        Buyers pay only <strong>0.2%</strong> and tenants pay <strong>0.5%</strong> of annual rent.
                        Traditional agents charge 2%–5%.
                    </p>
                </div>
            </div>

            <div class="col-md-4 mb-4">
                <div class="p-4 shadow-sm bg-white rounded h-100">
                    <h5 class="fw-bold text-dark">Verified Owners, Buyers & Tenants</h5>
                    <p>No fake leads or misleading ads. All users are identity-verified before connecting.</p>
                </div>
            </div>

        </div>

    </div>
</section>



    <!--=================================
        location -->
    <section class="space-pb">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="section-title text-center">
                        <h2>Find properties in Top Areas</h2>
                    </div>
                </div>
            </div>
            <div class="row">
    @php
        $locations = [
            ['name' => 'Dubai South', 'image' => 'images/location/dubaiSouth.png'],
            ['name' => 'Palm Jebel Ali', 'image' => 'images/location/palmJebelAli.png'],
            ['name' => 'Downtown Dubai', 'image' => 'images/location/downtownDubai.png'],
            ['name' => 'Business Bay', 'image' => 'images/location/businessBay.png'],
        ];
    @endphp

    @foreach($locations as $location)
        <div class="col-md-6 mb-4">
            <a href="{{ url('properties') }}?location={{ urlencode($location['name']) }}">
                <div class="location-item bg-overlay-gradient bg-holder"
                    style="background-image: url('{{ asset($location['image']) }}');">
                    <div class="location-item-info">
                        <h5 class="location-item-title">{{ $location['name'] }}</h5>
                        <span class="location-item-list">{{ $propertyCounts[$location['name']] ?? 0 }} Properties</span>
                    </div>
                </div>
            </a>
        </div>
    @endforeach
</div>

        </div>
    </section>
    <!--=================================
        location -->



    <!--=================================
        about-->

    <!-- <section class="space-ptb bg-holder bg-overlay-black-70" style="background-image: url(images/bg/01.jpg);">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-8 text-center position-relative">
                    <div class="section-title">
                        <span class="text-primary fw-bold d-block mb-3">Buy or sell</span>
                        <h2 class="text-white">Looking to buy a new property or sell an existing one? Direct Deal provides
                            an excellent solution!</h2>
                    </div>
                    <a class="btn btn-primary mb-2 mb-sm-0" href="#">Submit Property</a>
                    <a class="btn btn-white mb-2 mb-sm-0" href="{{ url('properties') }}">Browse Properties</a>
                </div>
            </div>
        </div>
    </section> -->

    <!--=================================
        about-->


<!--===============================================
     HOW DIRECT DEAL WORKS – SALES (Enhanced)
================================================-->

<section class="py-5" style="background:#ffffff;">
    <div class="container">

        <h2 class="mb-4 text-center" style="color:#26AE61; font-weight:800; font-size:32px;">
            How Direct Deal Works – <span style="color:#4A225B;">Property Sales</span>
        </h2>

        <div class="row justify-content-center">
            <div class="col-lg-10">

                <div class="p-4 rounded shadow-sm" style="background:#f7fdfb; border-left:6px solid #26AE61;">
                    <ol class="ps-3" style="font-size:18px; line-height:1.9; color:#333; list-style: none;">
                        
                        <li class="mb-4">
                            <strong style="color:#26AE61; font-size:20px;">
                                1. Owner Lists Property (Free)
                            </strong>
                            <br>
                            Upload photos & details — our team verifies ownership before going live.
                        </li>

                        <li class="mb-4">
                            <strong style="color:#26AE61; font-size:20px;">
                                2. Buyer Shows Interest
                            </strong>
                            <br>
                            Buyer contacts through Direct Deal → we verify ID & financial capability.
                        </li>

                        <li class="mb-4">
                            <strong style="color:#26AE61; font-size:20px;">
                                3. Direct Connection & Secure Offer Exchange
                            </strong>
                            <br>
                            Verified offers are shared safely. Direct Deal acts as a neutral intermediary.
                        </li>

                    </ol>
                </div>

                <div class="mt-4 text-center p-3 rounded" style="background:#e9f7f0;">
                    <p class="text-muted mb-1" style="font-size:15px;">
                        <strong class="text-dark">Contract Flow:</strong> Contract A (Seller) → Contract B (Buyer) → Contract F (Final Agreement)
                    </p>
                    <p class="small text-dark fw-bold">
                        Both parties submit a <span style="color:#26AE61;">10% security deposit</span>  
                        (refunded unless default occurs).
                    </p>
                </div>

            </div>
        </div>

    </div>
</section>


<!--=====================================================
     HOW DIRECT DEAL WORKS – RENTALS (Enhanced)
======================================================-->

<section class="py-5" style="background:#e9f7f0;">
    <div class="container">

        <h2 class="mb-4 text-center" style="color:#26AE61; font-weight:800; font-size:32px;">
            How Direct Deal Works – <span style="color:#4A225B;">Rentals</span>
        </h2>

        <div class="row justify-content-center">
            <div class="col-lg-10">

                <div class="p-4 rounded shadow-sm" style="background:#ffffff; border-left:6px solid #4A225B;">
                    <ol class="ps-3" style="font-size:18px; line-height:1.9; color:#333; list-style: none;">

                        <li class="mb-4">
                            <strong style="color:#4A225B; font-size:20px;">
                                1. Landlord Lists Property Free
                            </strong>
                            <br>
                            Ownership, photos & unit details are fully verified before listing goes live.
                        </li>

                        <li class="mb-4">
                            <strong style="color:#4A225B; font-size:20px;">
                                2. Tenant Shows Interest
                            </strong>
                            <br>
                            We verify tenant identity and rental capability to avoid time-wasters.
                        </li>

                        <li class="mb-4">
                            <strong style="color:#4A225B; font-size:20px;">
                                3. Tenancy Agreement & Ejari Support
                            </strong>
                            <br>
                            Direct Deal prepares the tenancy contract and assists with the complete process.
                        </li>

                    </ol>
                </div>

                <div class="mt-4 text-center p-3 rounded" style="background:#ffffff;">
                    <p class="text-dark mb-1 fw-bold" style="font-size:16px;">
                        Tenants pay only <span style="color:#26AE61;">0.5% of annual rent</span>
                        — not 5% brokerage.
                    </p>
                    <p class="small text-muted">
                        This covers documentation, verification, and Ejari support.
                    </p>
                </div>

            </div>
        </div>

    </div>
</section>




    <!--=================================
        Feature -->
    <section class="space-ptb bg-light">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-6">
                    <div class="section-title">
                        <h2>What You Pay</h2>
                    </div>
                </div>
                <div class="col-lg-6 d-none">
                    <div class="popup-video mb-4 text-lg-end">
                        <a class="popup-icon popup-youtube d-flex justify-content-lg-end"
                            href="https://www.youtube.com/watch?v=LgvseYYhqU0"> <span class="pe-3"> Play Video</span> <i
                                class="flaticon-play-button"></i> </a>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-4 col-sm-6 mb-4 mb-lg-0">
                    <div class="feature-info feature-info-02">
                        <div class="feature-info-detail">
                            <div class="feature-info-icon">
                                <i class="flaticon-like"></i>
                            </div>
                            <div class="feature-info-content">
                                <h6 class="mb-3 feature-info-title">For Sellers & Landlords</h6>
                                <p>0% Commission<br> No listing fees. No hidden charges.</p>
                            </div>
                            <!-- <div class="feature-info-button">
                                <a class="btn btn-light d-grid" href="#">Read more</a>
                            </div> -->
                        </div>
                        <div class="feature-info-bg bg-holder bg-overlay-black-70"
                            style="background-image: url('images/property/grid/01.jpg');"></div>
                    </div>
                </div>
                <div class="col-lg-4 col-sm-6 mb-4 mb-lg-0">
                    <div class="feature-info feature-info-02">
                        <div class="feature-info-detail">
                            <div class="feature-info-icon">
                                <i class="flaticon-agent"></i>
                            </div>
                            <div class="feature-info-content">
                                <h6 class="mb-3 feature-info-title">For Buyers</h6>
                                <p>0.2% Service Fee<br>Covers verification, contracts, and transfer coordination.</p>
                            </div>
                            <!-- <div class="feature-info-button">
                                <a class="btn btn-light d-grid" href="#">Read more</a>
                            </div> -->
                        </div>
                        <div class="feature-info-bg bg-holder bg-overlay-black-70"
                            style="background-image: url('images/property/grid/02.jpg');"></div>
                    </div>
                </div>
                <div class="col-lg-4 col-sm-6 mb-4 mb-sm-0">
                    <div class="feature-info feature-info-02">
                        <div class="feature-info-detail">
                            <div class="feature-info-icon">
                                <i class="flaticon-like-1"></i>
                            </div>
                            <div class="feature-info-content">
                                <h6 class="mb-3 feature-info-title">For Tenants</h6>
                                <p>Only 0.5% of Annual Rent<br>Covers tenancy contract, Ejari, and paperwork.</p>
                            </div>
                            <!-- <div class="feature-info-button">
                                <a class="btn btn-light d-grid" href="#">Read more</a>
                            </div> -->
                        </div>
                        <div class="feature-info-bg bg-holder bg-overlay-black-70"
                            style="background-image: url('images/property/grid/03.jpg');"></div>
                    </div>
                </div>
                <!-- <div class="col-lg-3 col-sm-6">
                    <div class="feature-info feature-info-02">
                        <div class="feature-info-detail">
                            <div class="feature-info-icon">
                                <i class="flaticon-house-1"></i>
                            </div>
                            <div class="feature-info-content">
                                <h6 class="mb-3 feature-info-title">Tons of options</h6>
                                <p>Discover a place you’ll love to live in. Choose from our vast inventory and choose your
                                    desired house.</p>
                            </div>
                            <div class="feature-info-button">
                                <a class="btn btn-light d-grid" href="#">Read more</a>
                            </div>
                        </div>
                        <div class="feature-info-bg bg-holder bg-overlay-black-70"
                            style="background-image: url('images/property/grid/04.jpg');"></div>
                    </div>
                </div> -->
            </div>
        </div>
    </section>
    <!--=================================
        Feature -->



    <!--=================================
        testimonial -->
    <section class="space-ptb">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <div class="section-title">
                        <h2>Testimonials</h2>
                    </div>
                    <div class="owl-carousel owl-nav-top-left" data-nav-arrow="true" data-items="1" data-md-items="1"
                        data-sm-items="1" data-xs-items="1" data-xx-items="1" data-space="0">
                        <div class="item">
                            <div class="testimonial-02">
                                <div class="testimonial-content">
                                    <p><i class="fas fa-quote-right quotes"></i>Had a great experience with Sharib from Direct Deals. He guided me through every step of my property investment — from identifying the right project to completing the purchase smoothly. Very professional, transparent, and knowledgeable. Highly recommend him and the Direct Deals team!</p>
                                </div>
                                <div class="testimonial-author">
                                    <div class="testimonial-avatar avatar avatar-lg me-3">
                                        <img class="img-fluid rounded-circle" src="images/avatar/01.jpg" alt="">
                                    </div>
                                    <div class="testimonial-name">
                                        <h6 class="text-primary mb-1">Vishnu</h6>
                                        <span>Dubai</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="testimonial-02">
                                <div class="testimonial-content">
                                    <p><i class="fas fa-quote-right quotes"></i>A 100% recommended firm in Dubai and Wonderful services by Direct Deal! All the agents are well-qualified and amazing in nature. They never get tired of answering queries—you can ask them any number of questions about the property. They offer several project options, both on-site and off-site. Not only do they connect you with the best developers, but they also provide you with the best deals.Thank you, Direct Deal, for your amazing services.</p>
                                </div>
                                <div class="testimonial-author">
                                    <div class="testimonial-avatar avatar avatar-lg me-3">
                                        <img class="img-fluid rounded-circle" src="images/avatar/02.jpg" alt="">
                                    </div>
                                    <div class="testimonial-name">
                                        <h6 class="text-primary mb-1">Manpreet Kaur</h6>
                                        <span>Dubai</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="testimonial-02">
                                <div class="testimonial-content">
                                    <p><i class="fas fa-quote-right quotes"></i>Absolutely loved the services of this firm. The agents are well qualified and experts in Dubai real estate market. They always gave professional advise in terms on the multiple options available for first time buyers. The company made the overall process smooth and I would strongly recommend their services to everyone, especially if you are a first time buyer.</p>
                                </div>
                                <div class="testimonial-author">
                                    <div class="testimonial-avatar avatar avatar-lg me-3">
                                        <img class="img-fluid rounded-circle" src="images/avatar/02.jpg" alt="">
                                    </div>
                                    <div class="testimonial-name">
                                        <h6 class="text-primary mb-1">Idrak Khan</h6>
                                        <span>Dubai</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="testimonial-02">
                                <div class="testimonial-content">
                                    <p><i class="fas fa-quote-right quotes"></i>“Mr. Sharib is an exceptional property broker in Dubai. With his engineering background and genuine advice, he helped me find the perfect property. Honest, loyal, and truly different from conventional brokers — highly recommended!”</p>
                                </div>
                                <div class="testimonial-author">
                                    <div class="testimonial-avatar avatar avatar-lg me-3">
                                        <img class="img-fluid rounded-circle" src="images/avatar/02.jpg" alt="">
                                    </div>
                                    <div class="testimonial-name">
                                        <h6 class="text-primary mb-1">engr.kanwal asif iqbal</h6>
                                        <span>Dubai</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="testimonial-02">
                                <div class="testimonial-content">
                                    <p><i class="fas fa-quote-right quotes"></i>Thanks to the Direct Deal! I could buy my first apartment in Dubai. Sales manager Shifa was very polite and helpful through the all process to choose and buy our dreamy house.
                                    Definitely will suggest this agency to my friends and colleagues!!</p>
                                </div>
                                <div class="testimonial-author">
                                    <div class="testimonial-avatar avatar avatar-lg me-3">
                                        <img class="img-fluid rounded-circle" src="images/avatar/02.jpg" alt="">
                                    </div>
                                    <div class="testimonial-name">
                                        <h6 class="text-primary mb-1">M.n.</h6>
                                        <span>Dubai</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 mt-5 mt-md-0">
                    <div class="section-title">
                        <h2>Frequently asked questions</h2>
                    </div>
                    <div class="accordion" id="accordion">
                        <div class="accordion-item border-0">
                            <div class="accordion-title" id="accordion-title-one">
                                <a href="#" data-bs-toggle="collapse" data-bs-target="#accordion-one"
                                    aria-expanded="true" aria-controls="accordion-one">01. Is listing really free for sale and rent?</a>
                            </div>
                            <div id="accordion-one" class="collapse show" aria-labelledby="accordion-title-one"
                                data-bs-parent="#accordion">
                                <div class="accordion-content">100% free for owners and landlords.</div>
                            </div>
                        </div>
                        <div class="accordion-item border-0">
                            <div class="accordion-title" id="accordion-title-tow">
                                <a href="#" class="collapsed" data-bs-toggle="collapse"
                                    data-bs-target="#accordion-two" aria-expanded="false"
                                    aria-controls="accordion-two">02. Why do tenants pay only 0.5%?</a>
                            </div>
                            <div id="accordion-two" class="collapse" aria-labelledby="accordion-title-tow"
                                data-bs-parent="#accordion">
                                <div class="accordion-content">This covers tenancy contract, Ejari, and documentation.</div>
                            </div>
                        </div>
                        <div class="accordion-item border-0">
                            <div class="accordion-title" id="accordion-title-three">
                                <a href="#" class="collapsed" data-bs-toggle="collapse"
                                    data-bs-target="#accordion-three" aria-expanded="false"
                                    aria-controls="accordion-three">03. Are listings verified?</a>
                            </div>
                            <div id="accordion-three" class="collapse" aria-labelledby="accordion-title-three"
                                data-bs-parent="#accordion">
                                <div class="accordion-content">No property goes live without full verification.</div>
                            </div>
                        </div>
                    </div>
                    <div class="mt-4">
                        <div class="d-flex align-items-center">
                            <span class="d-block me-3 text-dark"><b>Call us</b></span>
                            <i class="fas fa-phone bg-primary p-3 rounded-circle text-white fa-flip-horizontal"></i>
                            <h6 class="ps-3 mb-0 text-primary"><a href="tel:+971581144230">+971581144230</a></h6>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--=================================
        testimonial -->

        <!--=================================
     SEO FOOTER TEXT (Added)
=================================-->
<section class="py-4" style="background:#f7fdfb;">
    <div class="container text-center">

        <p class="mb-0" style="color:#4A225B; font-size:14px;">
            DirectDealUAE.com – Dubai’s trusted zero-commission property platform with verified listings,
            verified users, and direct real estate transactions.
        </p>

        <p class="small mt-2" style="color:#26AE61;">
            Buy property in Dubai | Sell property in Dubai | Rent in Dubai |
            Zero commission real estate | Verified listings | Dubai real estate portal
        </p>

    </div>
</section>

<!-- WhatsApp Floating Button -->
<a
  href="https://wa.me/971581144230?text=Hi%2C%20I%20just%20visited%20the%20DirectDealUAE%20website.%20Could%20you%20please%20share%20more%20details%3F"
  class="whatsapp-float"
  target="_blank"
  rel="noopener noreferrer"
>
  <img
    src="https://upload.wikimedia.org/wikipedia/commons/6/6b/WhatsApp.svg"
    alt="WhatsApp Chat"
    class="whatsapp-icon"
  />
</a>

<style>
.whatsapp-float {
  position: fixed;
  bottom: 25px;
  left: 25px;
  width: 60px;
  height: 60px;
  background-color: #25d366;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  box-shadow: 0 4px 10px rgba(0, 0, 0, 0.3);
  z-index: 9999;
  text-decoration: none;
}

.whatsapp-icon {
  width: 35px;
  height: 35px;
}
.whatsapp-float:hover {
  background-color: #1ebe5d;
}
.advance-dropdown-menu {
    position: absolute;
    top: 72px;
    left: 0;
    width: 260px;
    background: #fff;
    border-radius: 8px;
    z-index: 1000;
    display: none;
}

.advance-dropdown-menu.show {
    display: block;
}

.dropdown-label {
    font-size: 12px;
    color: #777;
    margin-bottom: 3px;
}

.advance-toggle {
    cursor: pointer;
}

.focus-none:focus {
    color: #fff;
}



.home .location-input-wrapper {
    position: relative;
}

.home .location-search-icon {
    position: absolute;
    top: 50%;
    left: 0px;
    transform: translateY(-50%);
    color: #999;
    font-size: 14px;
}

.home .location-input {
    padding-left: 20px; /* space for icon */
}

/* Dropdown */
.home .location-dropdown {
    position: absolute;
    top: calc(100% + 6px);
    left: 0;
    width: 100%;
    background: #fff;
    border-radius: 8px;
    box-shadow: 0 8px 20px rgba(0,0,0,0.15);
    z-index: 9999;
    max-height: 260px;
    overflow-y: auto;
    padding: 10px 0;
}

.home .location-title {
    font-size: 13px;
    font-weight: 600;
    padding: 8px 16px;
    color: #333;
}

.home .location-option {
    padding: 10px 16px;
    cursor: pointer;
    display: flex;
    align-items: center;
    gap: 8px;
    font-size: 14px;
}

.home .location-option:hover {
    background: #f5f5f5;
}

.home .location-option i {
    color: #26AE61;
    font-size: 14px;
}

.home .location-search-icon.fa-search:before {
    content: "\f002";
    color: #26ae61;
}
.property-search-field .form-control{border: none; cursor: pointer;}

input#location-input::placeholder {
    color: gray;
}
</style>
<script>



const input = document.getElementById('location-input');
const dropdown = document.getElementById('location-dropdown');
const items = dropdown.querySelectorAll('.location-option');

input.addEventListener('focus', () => {
    dropdown.classList.remove('d-none');
});

input.addEventListener('input', () => {
    const query = input.value.toLowerCase();

    let visibleCount = 0;

    items.forEach(item => {
        const text = item.dataset.value.toLowerCase();
        if (text.includes(query)) {
            item.style.display = 'flex';
            visibleCount++;
        } else {
            item.style.display = 'none';
        }
    });

    dropdown.classList.toggle('d-none', visibleCount === 0);
});

items.forEach(item => {
    item.addEventListener('click', () => {
        input.value = item.dataset.value;
        dropdown.classList.add('d-none');
    });
});

// Close on outside click
document.addEventListener('click', (e) => {
    if (!e.target.closest('.form-group')) {
        dropdown.classList.add('d-none');
    }
});


document.querySelector('.advance-toggle').addEventListener('click', function() {
    document.querySelector('.advance-dropdown-menu').classList.toggle('show');
});

// Close if clicking outside
document.addEventListener('click', function(e) {
    let dropdown = document.querySelector('.advance-dropdown-menu');
    let toggle = document.querySelector('.advance-toggle');
    if (!dropdown.contains(e.target) && !toggle.contains(e.target)) {
        dropdown.classList.remove('show');
    }
});
</script>

@endsection
